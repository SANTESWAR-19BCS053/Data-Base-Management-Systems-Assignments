/* Query-1("=") */
SELECT * FROM T3_EMPLOYEE_DETAILS WHERE Designation = 'Cleaner';
/* Query-2("=") */
SELECT * FROM T3_CUSTOMER_DETAILS WHERE Gender = 'F';

/* Query-1(">") */
SELECT * FROM T3_CUSTOMER_DETAILS WHERE Customer_ID > '0000000005';
/* Query-2(">") */
SELECT * FROM T3_BUS WHERE Booking_ID > '0100010';

/* Query-1("<") */
SELECT * FROM T3_EMPLOYEE_DETAILS WHERE Salary < 12000;
/* Query-2("<") */
SELECT * FROM T3_BUS WHERE Booking_ID < '0100012';

/* Query-1(">=") */
SELECT * FROM T3_CUSTOMER_DETAILS WHERE Phone_No >= '919999999998';
/* Query-2(">=") */
SELECT * FROM T3_EMPLOYEE_DETAILS WHERE Salary >= 12000;

/* Query-1("<=") */
SELECT * FROM T3_CUSTOMER_DETAILS WHERE Age <= 20 AND Customer_ID > '0000000015';
/* Query-2("<=") */
SELECT * FROM T3_EMPLOYEE_DETAILS WHERE Salary <= 10000;

/* Query-1("!=") */
SELECT * FROM T3_CUSTOMER_DETAILS WHERE First_Name <> 'Shreya' AND Gender <> 'M';
/* Query-2("!=") */
SELECT * FROM T3_BUS WHERE Bus_ID <> '8714';
