/* Query-1("AND") */
SELECT Customer_ID, First_Name, Last_Name FROM T3_CUSTOMER_DETAILS WHERE Age = 18 AND Gender = 'M';
/* qUERY-2("AND") */
SELECT Employee_ID, Phone_No FROM T3_EMPLOYEE_DETAILS WHERE Designation = 'Driver' AND Salary > 10000;



/* Query-1("OR") */
SELECT Hotel_Description, Booking_ID FROM T3_DESTINATION_DETAILS WHERE Hotel_Name = 'Raj Palace' OR City = 'Burang';
/* qUERY-2("OR") */
SELECT Bus_ID, Booking_ID FROM T3_BUS WHERE Bus_Type = 'Sleeper' OR DateAndTime_Of_Arrival = '2021-03-04T05:30:00';



/* Query-1("NOT") */
SELECT Employee_ID, Name, Salary, Phone_No FROM T3_EMPLOYEE_DETAILS WHERE NOT Employee_ID = '01001';
/* qUERY-2("NOT") */
SELECT Customer_ID, First_Name, Last_Name, Age FROM T3_CUSTOMER_DETAILS WHERE NOT Age > 29;



/* Query-1("IN") */
SELECT * FROM T3_CUSTOMER_DETAILS WHERE Gender IN ('M');
/* qUERY-2("IN") */
SELECT * FROM T3_EMPLOYEE_DETAILS WHERE Salary IN(5000, 12500);



/* Query-1("BETWEEN") */
SELECT * FROM T3_CUSTOMER_DETAILS WHERE Age BETWEEN 15 AND 30;

/* qUERY-2("BETWEEN") */
SELECT * FROM T3_EMPLOYEE_DETAILS WHERE Salary BETWEEN 1000 AND 15000;