/*Query-1*/
SELECT First_Name, Last_Name, Phone FROM T3_CUSTOMER_DETAILS 
WHERE Customer_ID IN 
					(SELECT Customer_ID FROM T3_BOOKING_DETAILS
					WHERE Payment_Amount > 30000);

/*Query-2*/
SELECT Package_Name, Starting_Point FROM T3_PACKAGE_DETAILS
WHERE EXISTS 
			(SELECT * FROM T3_BUS WHERE T3_PACKAGE_DETAILS.Booking_ID = T3_BUS.Booking_ID);

/*Query-3*/
SELECT Customer_ID FROM T3_CUSTOMER_DETAILS 
WHERE Customer_ID IN 
					(SELECT Customer_ID FROM T3_BOOKING_DETAILS 
					WHERE Booking_ID IN 
										(SELECT Booking_ID FROM T3_DESTINATION_DETAILS
										WHERE Hotel_Name = 'Gurugrantha Choultry'));

/*Query-4*/
SELECT Package_Name, cost FROM T3_PACKAGE_DETAILS 
WHERE Booking_ID IN 
					(SELECT Booking_ID FROM T3_BUS WHERE Bus_Type = '3 Seater');

/*Query-5*/
SELECT Customer_ID, First_Name, Age, Gender FROM T3_CUSTOMER_DETAILS 
WHERE Customer_ID NOT IN 
						(SELECT Customer_ID FROM T3_BOOKING_DETAILS
						WHERE Booking_ID IN 
											(SELECT Booking_ID from T3_PACKAGE_DETAILS 
											WHERE Package_Name='KULU MANALI'));



