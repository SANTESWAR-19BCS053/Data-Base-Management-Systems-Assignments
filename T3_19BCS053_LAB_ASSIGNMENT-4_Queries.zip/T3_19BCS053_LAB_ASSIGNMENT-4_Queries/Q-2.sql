/*Query-1*/
SELECT CONCAT(Bus_ID, ' ', Bus_Type) AS Bus_Details, Booking_ID, DateAndTime_Of_Arrival, DateAndTime_Of_Departure 
FROM T3_BUS;

/*Query-2*/
SELECT TOP 1 CONCAT(Package_Name, ', ', Package_Description) AS Package FROM T3_PACKAGE_DETAILS
WHERE Booking_ID = 0100009 OR Booking_ID = 0200013;

/*Query-3*/
SELECT CONCAT(First_Name, ' ', Last_Name) AS Full_Name, Customer_ID, Phone_No FROM T3_CUSTOMER_DETAILS;
