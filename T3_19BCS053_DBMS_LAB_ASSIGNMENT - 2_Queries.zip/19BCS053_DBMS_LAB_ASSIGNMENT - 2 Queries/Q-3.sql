USE Travel;
CREATE TABLE CustomerDetails
(
	customer_id CHAR(10) PRIMARY KEY NOT NULL,
	first_name VARCHAR(20) NOT NULL, 
	last_name VARCHAR(20) NOT NULL,
	age INT NOT NULL,
	gender CHAR(1) NOT NULL,
	phone VARCHAR(12) NOT NULL,
	address TEXT NOT NULL 
);
CREATE TABLE BookingDetails
(
	customer_id CHAR(10) FOREIGN KEY REFERENCES CustomerDetails(customer_id) NOT NULL,
	booking_id CHAR(7) PRIMARY KEY NOT NULL,
	payment_amount DECIMAL(10,2) NOT NULL, 
	payment_dateTime DATETIME NOT NULL,
	refunded CHAR(1),
	refund_amount DECIMAL(10,2),
	refund_dateTime DATETIME
);
CREATE TABLE PackageDetails
(
	package_name VARCHAR(15) PRIMARY KEY NOT NULL,
	package_description TEXT NOT NULL,
	cost DECIMAL(10,2) NOT NULL,
	starting_point VARCHAR(15) NOT NULL,
	booking_id CHAR(7) FOREIGN KEY REFERENCES BookingDetails(booking_id) NOT NULL 
);
CREATE TABLE DestinationDetails
(
	package_name VARCHAR(15) FOREIGN KEY REFERENCES PackageDetails(package_name) NOT NULL, 
	city_id CHAR(4) PRIMARY KEY NOT NULL,
	city VARCHAR(15) NOT NULL 
);
CREATE TABLE HotelsAtDestination
(
	city_id CHAR(4) FOREIGN KEY REFERENCES DestinationDetails(city_id) NOT NULL,
	hotel_id CHAR(3) PRIMARY KEY NOT NULL,
	hotel_name VARCHAR(10) NOT NULL,
	hotel_description TEXT NOT NULL,
	address TEXT NOT NULL 
);
CREATE TABLE EmployeeDetails
(
	employee_id CHAR(5)	PRIMARY KEY NOT NULL, 
	name VARCHAR(10) NOT NULL,
	designation VARCHAR(15) NOT NULL,
	phone_number VARCHAR(12) NOT NULL,
	salary DECIMAL(10,2) NOT NULL 
);
CREATE TABLE Car
(
	package_name VARCHAR(15) FOREIGN KEY REFERENCES PackageDetails(package_name) NOT NULL,
	car_id CHAR(10) PRIMARY KEY NOT NULL,
	car_model VARCHAR(10) NOT NULL,
	employee_id CHAR(5) FOREIGN KEY REFERENCES EmployeeDetails(employee_id) NOT NULL,
	dateAndTime_Of_Pickup DATETIME NOT NULL, 
	dateAndTime_Of_Drop DATETIME NOT NULL 
);
CREATE TABLE Bus
(
	package_name VARCHAR(15) FOREIGN KEY REFERENCES PackageDetails(package_name) NOT NULL,
	bus_id CHAR(4) PRIMARY KEY NOT NULL,
	bus_type VARCHAR(10) NOT NULL,
	employee_id CHAR(5) FOREIGN KEY REFERENCES EmployeeDetails(employee_id) NOT NULL,
	dateAndTime_Of_Arrival DATETIME NOT NULL, 
	dateAndTime_Of_Departure DATETIME NOT NULL 
);
CREATE TABLE Flight
(
	package_name VARCHAR(15) FOREIGN KEY REFERENCES PackageDetails(package_name) NOT NULL,
	flight_id CHAR(8) PRIMARY KEY NOT NULL,
	flight_class VARCHAR(10) NOT NULL,
	dateAndTime_Of_boarding DATETIME NOT NULL,
	dateAndTime_Of_landing DATETIME NOT NULL 
);
CREATE TABLE Train
(
	package_name VARCHAR(15) FOREIGN KEY REFERENCES PackageDetails(package_name) NOT NULL,
	train_no CHAR(8) PRIMARY KEY NOT NULL,
	train_Class VARCHAR(10) NOT NULL,
	dateAndTime_Of_Arrival DATETIME NOT NULL,
	dateAndTime_Of_Departure DATETIME NOT NULL 
);
