CREATE TABLE Guests
(
	guest_id CHAR(10) PRIMARY KEY NOT NULL,
	name VARCHAR(25) NOT NULL,
	dateOfBirth DATE NOT NULL,
	age AS DATEDIFF(YEAR, dateOfBirth, GETDATE()),
	mobile_no VARCHAR(20) NOT NULL
);