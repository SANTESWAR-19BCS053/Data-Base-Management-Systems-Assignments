CREATE TABLE Guests
(
	name CHAR(10) PRIMARY KEY NOT NULL,
	phone_number CHAR(10) NOT NULL,
	address VARCHAR(200) ,
	age INT 
);

DROP TABLE Guests;